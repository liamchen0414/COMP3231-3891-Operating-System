#include <types.h>
#include <kern/errno.h>
#include <kern/fcntl.h>
#include <kern/limits.h>
#include <kern/stat.h>
#include <kern/seek.h>
#include <lib.h>
#include <uio.h>
#include <proc.h>
#include <current.h>
#include <synch.h>
#include <vfs.h>
#include <vnode.h>
#include <file.h>
#include <syscall.h>
#include <copyinout.h>
#include <limits.h>

/*
 * just a default mode constant
 */
#define DEFAULTMODE 0

/*
 * Notes for copyin/out:
 * 1. we already use copyin for whence, we use it because we can't trust user stack pointer
 *    it checks whehter the memory is valid or not, and if we can access it
 * 2. copyout does the opposite to copyin
 * 3. copyinstr and copyoutstr are similar to copyin and copyout.
 *    The side of the strings are determined by the null termination of the string
 *    if safely accesses the
 */

/*
 * Add your file-related functions here ...
 */

/*
 * Check if a file descriptor is valid
 */
static int check_valid_fd(int fd)
{
    if (fd < 0 || fd >= OPEN_MAX)
    {
        return EBADF;
    }
    return 0;
}

// int sys_open2(const char *filename, int flags)
// {
//     (void)filename;
//     (void)flags;
//     return 0;
// }

/*
 * open opens the file, device, or other kernel object named by the pathname filename. The flags argument specifies how to open the file.
 * The optional mode argument provides the file permissions to use and is only meaningful in Unix,
 * or if you choose to implement Unix-style security later on. it can be ignored in OS/161.
 */
int sys_open(const char *filename, int flags, mode_t mode, int *retval)
{
    // kprintf("sys_open called with filename %s, flags %d\n", filename, flags);
    mode = DEFAULTMODE;

    const int openflags = O_ACCMODE | O_CREAT | O_EXCL | O_TRUNC | O_APPEND;
    struct openfile *file;
    struct filedescriptor *fd;
    int result = 0;

    /* if file name is invalid pointer */
    if (filename == NULL)
    {
        return EFAULT;
    }

    /* we cannot trust any string provided by the user,
     * we need to use copy in/out to safely copy the string in and out
     */
    char *kernel_filename = (char *)kmalloc(PATH_MAX);
    if (kernel_filename == NULL)
    {
        return ENOMEM;
    }

    /* checking user supplied filename is valid */
    result = copyinstr((const_userptr_t)filename, kernel_filename, PATH_MAX, NULL);
    if (result)
    {
        kfree(kernel_filename); // invalid application file name, free the memory and return error code
        return result;
    }

    /* if the masks return flags that are not equal, the flags are invalid*/
    if ((flags & openflags) != flags)
    {
        return EINVAL;
    }

    /* O_EXCL is only meaningful if O_CREAT is also used. */
    if ((flags & O_EXCL) && !(flags & O_CREAT))
    {
        return EEXIST;
    }
    /*
     * create an open file entry; if failed, free the previously malloc'd pathname and return
     */
    result = openfile_create(kernel_filename, flags, mode, &file);
    if (result)
    {
        kfree(kernel_filename);
        return result;
    }

    /* create the file descriptor linking to the open file */
    fd = fd_create(file);

    /* insert the file descriptor and open file into their tables */
    result = fd_insert(curproc->fdtable, fd, retval);
    if (result)
    {
        return result;
    }

    /* add the open file entry to the file table */
    result = oft_insert(of_t, file);
    if (result)
    {
        /* decrement the reference count, if the reference count is 0, destroy the open file entry
         * if file table entry can't be inserted, we need to destroy the open file entry
         */
        dec_refcount(file);
        return result;
    }

    // kprintf("this should be same as file descriptor %d\n", file_handle);
    return 0;
}

/*
 * sys_close closes the file descriptor fd.
 */
int sys_close(int fd)
{
    struct openfile *file;
    int result;

    result = check_valid_fd(fd);
    if (result)
    {
        return result;
    }
    result = oft_read(of_t, fd, &file); /* given the file descriptor, read the global file table */
    if (result)
    {
        return result;
    }
    of_t->openfiles[fd] = NULL;      /* remove the open file from the global file table */
    fd_remove(curproc->fdtable, fd); /* remove the file descriptor from the process file descriptor table */
    return 0;
}

/*
 * Notes for read and write:
 * 1. we need to keep track of the file pointer, where the next operation is going to perform on (file pointer)
 * 2. file pointer is associated with the file descriptor, however if we open the same file twice, we have 2 different file descriptors
 *    now if we perform writes to the buffer, the second write will overwrite the first write because file pointers are pointing at the same location
 */

ssize_t sys_read(int fd, void *buf, size_t buflen, int *retval)
{

    int result;
    off_t offset;
    int flags;
    struct iovec iov;
    struct uio u_uio;
    struct openfile *file;
    /* check if file descriptor is valid */
    // kprintf("debug line 190, printing fd %d\n", fd);
    result = check_valid_fd(fd);
    if (result)
    {
        return result;
    }

    /* read the open file entry to file */
    result = oft_read(of_t, fd, &file);
    if (result)
    {
        return result;
    }
    // kprintf("debug line: 201");
    bool lseekable = VOP_ISSEEKABLE(file->vn);
    /* if the file is lseekable, then a thread can move the file pointer to another location*/
    /* we don't want this to happen so we lock the offset lock so different threads start reading from correc offsets */
    if (lseekable)
    {
        lock_acquire(file->file_offset_lock);
        offset = file->file_offset;
    }
    else
    {
        offset = 0;
    }
    /* check the access mode on file */
    flags = file->access_mode;
    if (flags & O_WRONLY) // if the file is write only, check if a lock is, if yes, release the lock before return
    {
        if (lseekable)
        {
            lock_release(file->file_offset_lock); // release the lock if locked
        }
        return EBADF;
    }
    uio_uinit(&iov, &u_uio, (userptr_t)buf, buflen, offset, UIO_READ);
    result = VOP_READ(file->vn, &u_uio);
    if (result)
    {
        if (lseekable)
        {
            lock_release(file->file_offset_lock); // release the lock if locked
        }
        return result;
    }

    if (lseekable)
    {
        file->file_offset = u_uio.uio_offset;
        lock_release(file->file_offset_lock);
    }
    *retval = buflen - u_uio.uio_resid;
    // kprintf("debug line: 241");
    return 0;
}

ssize_t sys_write(int fd, const void *buf, size_t nbytes, int *retval)
{
    int result;
    off_t offset;
    int flags;
    struct iovec iov;
    struct uio u_uio;
    struct openfile *file;
    /* check if file descriptor is valid */
    result = check_valid_fd(fd);
    if (result)
    {
        return result;
    }

    /* read the open file entry to file */
    result = oft_read(of_t, fd, &file);
    if (result)
    {
        return result;
    }
    bool lseekable = VOP_ISSEEKABLE(file->vn);
    /* if the file is lseekable, then a thread can move the file pointer to another location*/
    /* we don't want this to happen so we lock the offset lock so different threads start reading from correc offsets */
    if (lseekable)
    {
        lock_acquire(file->file_offset_lock);
        offset = file->file_offset;
    }
    else
    {
        offset = 0;
    }
    /* check the access mode on file */
    flags = file->access_mode;
    if (flags & O_RDONLY || flags == O_CREAT) // if the file is read only, return error
    {
        if (lseekable)
        {
            lock_release(file->file_offset_lock); // release the lock if locked
        }
        return EBADF;
    }
    /* O_APPEND causes all writes to the file to occur at the end of file, no matter what gets written to the file by whoever else */
    /* This is not required, see #509 */
    uio_uinit(&iov, &u_uio, (userptr_t)buf, nbytes, offset, UIO_WRITE);
    result = VOP_WRITE(file->vn, &u_uio);
    if (result)
    {
        if (lseekable)
        {
            lock_release(file->file_offset_lock); // release the lock if locked
        }
        return result;
    }

    if (lseekable)
    {
        file->file_offset = u_uio.uio_offset;
        lock_release(file->file_offset_lock);
    }
    *retval = nbytes - u_uio.uio_resid;
    return 0;
}

/*
 * Notes for dup2:
 * 1. with dup2, if we copy the fd, there is a file pointer shared between the two file descriptors
 */
int sys_dup2(int oldfd, int newfd, int *retval)
{
    /* newfd in range */
    int result = check_valid_fd(newfd);
    if (result)
    {
        return result;
    }

    /* oldfd in range */
    result = check_valid_fd(oldfd);
    if (result)
    {
        return result;
    }

    /* check oldfd exists */
    if (curproc->fdtable[oldfd] == NULL)
    {
        return EBADF;
    }

    /* if newfd = oldfd, do nothing */
    if (oldfd == newfd)
    {
        *retval = newfd;
        return 0;
    }

    /* check newfd names already-open file */
    if (curproc->fdtable[newfd] != NULL)
    {
        /* decrement (or close if ref count is now 0) ref counter of
         * openfile which newfd previously pointed to 
        */
        dec_refcount(curproc->fdtable[newfd]->ofptr);
        inc_refcount(curproc->fdtable[oldfd]->ofptr);
        /* newfd now points to same openfile as oldfd */
        curproc->fdtable[newfd] = curproc->fdtable[oldfd];
        *retval = newfd;
    }
    return 0;
}

off_t sys_lseek(int fd, off_t pos, int whence, off_t *retval)
{
    struct openfile *of;
    int result;
    off_t new_offset = 0;
    struct stat file_stat;

    /* checking valid file handle */
    if (fd < 0 || fd > OPEN_MAX - 1 || curproc->fdtable[fd] == NULL)
    {
        return EBADF;
    }

    /* access the open file pointer within the specified file descriptor */
    of = curproc->fdtable[fd]->ofptr;
    if (!VOP_ISSEEKABLE(of->vn))
    {
        // kprintf("sys_lseek: trying to seek unseekable file: with fd index %d\n", fd);
        return ESPIPE;
    }

    /* checking whence */
    if (!(whence == SEEK_SET || whence == SEEK_CUR || whence == SEEK_END))
    {
        // kprintf("invalid argument error line 354\n");
        return EINVAL;
    }

    /* acquire lock */
    lock_acquire(of->file_offset_lock);

    switch (whence)
    {
    case SEEK_SET:
        new_offset = pos;
        break;
    case SEEK_CUR:
        new_offset = (of->file_offset) + pos;
        break;
    case SEEK_END:
        /* find file size, i.e. position of EOF */
        result = VOP_STAT(of->vn, &file_stat);
        if (result) {
            lock_release(of->file_offset_lock);
            return result;
        }

        new_offset = file_stat.st_size + pos;
        break;
    default:
        lock_release(of->file_offset_lock);
        return EINVAL;
    }

    /* check for invalid offset */
    if (new_offset < 0) {
        // kprintf("invalid argument error line 381\n");
        lock_release(of->file_offset_lock);
        return EINVAL;

    }

    /* set offset in openfile struct, store new offset into retval */
    of->file_offset = new_offset;
    *retval = new_offset;
    lock_release(of->file_offset_lock);

    return 0;
}

/* =========================================================
 * file descriptor code here, 2a.m ken again
 * =========================================================
 */

struct filedescriptor *fd_create(struct openfile *ofptr)
{
    struct filedescriptor *fd = kmalloc(sizeof(struct filedescriptor));
    if (fd == NULL)
    {
        return NULL;
    }
    fd->ofptr = ofptr; /* point this at the open file pointer */
    return fd;
}

/*
 * pass in a file descriptor table fdtable, a file descriptor fd, and a pointer to an open file pointer
 */

int fd_insert(struct filedescriptor *fdtable[OPEN_MAX], struct filedescriptor *fd, int *ret)
{
    if (fdtable == NULL)
    {
        return EFAULT;
    }
    for (int index = 1; index < OPEN_MAX; index++) /* 0,1,2 are reserved */
    {
        if (fdtable[index] == NULL)
        {
            fdtable[index] = fd;
            *ret = index;
            // kprintf("you have file descriptor: %d\n", index);
            return 0;
        }
    }
    return EMFILE;
}

int fd_remove(struct filedescriptor *fdtable[OPEN_MAX], int fd)
{
    if (fdtable == NULL)
    {
        return EFAULT;
    }

    /* remember to decrement the reference counter of the matching openfile */
    dec_refcount(fdtable[fd]->ofptr);
    fdtable[fd] = NULL;
    return 0;
}

/* =========================================================
 * open file entry code here
 * =========================================================
 */

/*
 * create an open file entry
 */
struct openfile *init_openfile(struct vnode *vn, int access_mode)
{
    // kprintf("init_openfile called with flags: %d\n", access_mode);

    struct openfile *of_entry;
    of_entry = kmalloc(sizeof(struct openfile)); /* assign memory to open file entry */
    if (of_entry == NULL)
    {
        return NULL;
    }
    spinlock_init(&of_entry->ref_count_lock);                     /* initialise the spinlock */
    of_entry->file_offset_lock = lock_create("file_offset_lock"); /* initialise the lock */
    if (of_entry->file_offset_lock == NULL)
    {
        kfree(of_entry);
        return NULL; /* need to return a pointer, not int */
    }
    of_entry->access_mode = access_mode;
    of_entry->vn = vn;
    of_entry->ref_count = 1;
    of_entry->file_offset = 0;
    return of_entry;
}

/*
 * destroy an open file entry
 */
void destory_openfile(struct openfile *of_entry)
{
    KASSERT(of_entry != NULL && of_entry->vn != NULL); /* sanity check */
    vfs_close(of_entry->vn);                           /* close vnode */
    spinlock_cleanup(&of_entry->ref_count_lock);       /* clean up the spinlock */
    lock_destroy(of_entry->file_offset_lock);          /* destroy lock */
    kfree(of_entry);                                   /* free the memory */
}

/*
 * insert an open file entry into filetable
 */
int oft_insert(struct filetable *of_t, struct openfile *of)
{
    for (int i = 0; i < OPEN_MAX; ++i)
    {
        if (of_t->openfiles[i] == NULL)
        {
            of_t->openfiles[i] = of;
            return 0;
        }
    }

    return EMFILE; /* there should be a more appropriate code to return here */
}

/*
 * open a file and create open file table entry
 */
int openfile_create(char *filename, int flags, mode_t mode, struct openfile **of_pointer)
{
    int result;
    struct vnode *vn;
    /* vfs_open handles most of the errors outlined in open manual */
    result = vfs_open(filename, flags, mode, &vn);
    if (result)
    {
        return result;
    }
    /* point the open file pointer at the newly created open file */
    *of_pointer = init_openfile(vn, flags);
    if (*of_pointer == NULL)
    {
        vfs_close(vn);
        return ENOMEM;
    }
    return 0;
}

/*
 * increment the reference count of the open file entry
 */
void inc_refcount(struct openfile *of_entry)
{
    spinlock_acquire(&of_entry->ref_count_lock);
    of_entry->ref_count++;
    spinlock_release(&of_entry->ref_count_lock);
}

/*
 * decrement the reference count of the open file entry
 */
void dec_refcount(struct openfile *of_entry)
{
    spinlock_acquire(&of_entry->ref_count_lock);
    if (of_entry->ref_count >= 1)
    {
        of_entry->ref_count--;
        if (of_entry->ref_count == 0)
        {
            spinlock_release(&of_entry->ref_count_lock);
            destory_openfile(of_entry);
            return;
        }
    }
    spinlock_release(&of_entry->ref_count_lock);
}

/* =========================================================
 * global file table code here
 * =========================================================
 */

/*
 * initialise a file table, create the file table
 * initialise the file descriptor table, add connection handles (stdout, stderr)
 */
int tables_init(const char *stdin, const char *stdout, const char *stderr)
{
    int result;
    struct openfile *ofp;
    // char kpath[PATH_MAX];    // unused
    struct filedescriptor *fd1, *fd2;

    /* see global declaration in file.h */
    of_t = oft_create(); // create the file table
    if (of_t == NULL)
    {
        return ENOMEM;
    }
    /* curproc->fdtable should be already initialised when proc was created */

    /* connect to stdin */
    char conname[5];
    strcpy(conname, stdin);
    result = openfile_create(conname, O_RDONLY, 0, &ofp);
    if (result)
    {
        kfree(curproc->fdtable);
        return result;
    }
    oft_insert(of_t, ofp);

    /* connect to stdout */
    strcpy(conname, stdout);
    result = openfile_create(conname, O_WRONLY, 0, &ofp);
    if (result)
    {
        kfree(curproc->fdtable);
        return result;
    }
    oft_insert(of_t, ofp);

    fd1 = kmalloc(sizeof(struct filedescriptor));
    fd1->ofptr = ofp;
    curproc->fdtable[1] = fd1;

    /* connect to stderr */
    strcpy(conname, stderr);
    result = openfile_create(conname, O_WRONLY, 0, &ofp);
    if (result)
    {
        kfree(curproc->fdtable);
        return result;
    }
    oft_insert(of_t, ofp);

    fd2 = kmalloc(sizeof(struct filedescriptor));
    fd2->ofptr = ofp;
    curproc->fdtable[2] = fd2;

    return 0;
}

/*
 * Create an empty file table
 */
struct filetable *
oft_create(void)
{
    // FIXME: TODO: does this actually work lol
    if (of_t == NULL)
    {
        of_t = kmalloc(sizeof(struct filetable));
        if (of_t == NULL)
        {
            return NULL;
        }

        /* initialise the file table to nulls */
        for (int i = 0; i < __OPEN_MAX; i++)
        {
            of_t->openfiles[i] = NULL;
        }
    }

    return of_t;
}

/*
 * Destroy a file table
 */
void oft_destory(struct filetable *oft)
{
    KASSERT(oft != NULL);
    /* Note: we need to first close any open files before freeing the entire table */
    for (int i = 0; i < OPEN_MAX; i++)
    {
        if (oft->openfiles[i] != NULL)
        {
            // dec_refcount(oft->openfiles[i]); //TODO
            oft->openfiles[i] = NULL;        /* Liam: we can't free here otherwise error will occur */
        }
    }
    kfree(oft);
}

/*
 * This function checks if the file descriptor is valid and returns the open file entry
 */
int oft_read(struct filetable *oft, int fd, struct openfile **of)
{
    int result;
    result = check_valid_fd(fd);
    if (result)
    {
        return result;
    }
    if (oft->openfiles[fd] == NULL)
    {
        return EBADF;
    }
    *of = oft->openfiles[fd];
    return 0;
}

/* =========================================================
 * Advanced part
 * =========================================================
 */

/*
 * Notes for fork:
 * 1. file pointer is shared between the parent and the child, if parent writes to the fd, the child will also write to the fd (added to where file pointer is)
 * 2. data structure associated in lecture 10 page 20 ish?
 * 3. we only need to set up the console for 1 and 2
 * 4. in the absence of fork(), there is a one-to-one mapping from the file descriptor table to the open file table.
 *    But in fork, the child process inherits all of the parent's file descriptors,
 *    but new entiries are not created in the system-wide open file table. In this case, reads and writes in one process
 *    can affect another process. If the parent reads or writes, it will move the offset pointer in the open file table
 *    This will affect the parent and all children, vice versa for operations performed by the children
 */
pid_t sys_fork(void)
{
    return 0;
}