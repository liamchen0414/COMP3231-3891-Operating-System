#define O_RDONLY      0      /* Open for read */
#define O_WRONLY      1      /* Open for write */
#define O_RDWR        2      /* Open for read and write */
/* then or in any of these: */
#define O_CREAT       4      /* Create file if it doesn't exist */
#define O_EXCL        8      /* With O_CREAT, fail if file already exists */
#define O_TRUNC      16      /* Truncate file upon open */
#define O_APPEND     32      /* All writes happen at EOF (optional feature) */
#define O_NOCTTY     64      /* Required by POSIX, != 0, but does nothing */

/* Additional related definition */
#define O_ACCMODE     3      /* mask for O_RDONLY/O_WRONLY/O_RDWR */

#include <stdio.h>
int main(){
    int flags = O_WRONLY | O_APPEND;
    flags = flags & O_WRONLY;
    if(flags == O_WRONLY){
        printf("O_WRONLY\n");
    }
}
