/*
 * Declarations for file handle and file table management.
 */

#ifndef _FILE_H_
#define _FILE_H_

/*
 * Contains some file-related maximum length constants
 */
#include <limits.h>
#include <spinlock.h>
#include <vnode.h>

struct filedescriptor
{
    struct openfile *ofptr; /* open file pointer to an openfile struct, where read or write should occur */
};

/*
 * Creates a file descriptor, shouldn't this just return an integer?
 */

struct filedescriptor *fd_create(struct openfile *ofptr);

/*
 * Inserts a file descriptor into the fdtable into the first available slot
 * Returns 0 if success, EMFILE if no available slot or fail
 * Stores index of newly placed fd in ret
 */
int fd_insert(struct filedescriptor *fdtable[OPEN_MAX], struct filedescriptor *fd, int *ret);

/*
 * remove a file descriptor from the fdtable, set the oft at fd to NULL
 */
int fd_remove(struct filedescriptor *fdtable[OPEN_MAX], int fd);

/*
 * Global open file table array, contains entries with a fp and a pointer to vnode
 * The maximum number of files that can be open is defined by OPEN_MAX
 */

/* global open file table */
struct filetable *of_t;

struct filetable
{
    struct openfile *openfiles[OPEN_MAX]; /* array of open file entries */
};

/*
 * connect stdin, stdout and stderr paths, this allows the file descriptor table to
 * search for the smalles free position starting from port 3 (after stderr 2)
 */
int oft_init(const char *stdin, const char *stdout, const char *stderr);

/*
 * Create an empty file table
 */
struct filetable *oft_create(void);

/*
 * destroy a given file table
 */
void oft_destory(struct filetable *oft);

/*
 * Inserts an open file entry into global open file table, similar to fd_insert
 * Returns 0 if success, EMFILE if no available slot or fail
 */
int oft_insert(struct filetable *of_t, struct openfile *of);

/*
 * This function checks if the file descriptor is valid and returns the open file entry
 */
int oft_read(struct filetable *oft, int fd, struct openfile **of);

/*
 * Initialises fd and of tables for a given process
 * function checks to ensure only 1 (global) of table is ever made
 *
 */
int tables_init(const char *stdin, const char *stdout, const char *stderr);

/*
 * open file entry struct:
 * contains file pointer(shared if required), pointer to an vnode, and reference count
 * we also need locks to protect the table and prevent race conditions.
 * The spinlock must be acquired before the binding between c0 and the reference count.
 * WE NEED TO BE CAREFUL with how they are shared via fork and dup2
 * see notes in syscalls.c notes for information
 */
struct openfile
{
    int access_mode;                /* we store the access mode from open syscall here*/
    struct vnode *vn;               /* pointer to vnode */
    unsigned int ref_count;         /* unsigned int because we'll never have negative reference count */
    struct spinlock ref_count_lock; /* spinlock for reference count, for advanced assignment when we fork */
    off_t file_offset;              /* the file pointer offset */
    struct lock *file_offset_lock;  /* lock for file pointer offset */
};

/*
 * create an open file entry
 */
struct openfile *init_openfile(struct vnode *vn, int access_mode);

/*
 * destroy an open file entry
 */
void destory_openfile(struct openfile *of_entry);

/*
 * open a file and create its entry in the open file table
 */
int openfile_create(char *filename, int flags, mode_t mode, struct openfile **of_pointer);

/*
 * increment the reference count of an open file entry
 */
void inc_refcount(struct openfile *of_entry);

/*
 * decrement the reference count of an open file entry
 * when the reference count is 0, remove the open file entry from the file table
 */
void dec_refcount(struct openfile *of_entry);

#endif /* _FILE_H_ */
