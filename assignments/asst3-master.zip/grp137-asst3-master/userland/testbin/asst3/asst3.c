/* super simple test program */

#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <unistd.h>

static const char *string1 = "ASST3 Hello World!!";

int main()
{
	printf("\n%s\n\n", string1);
	return 0;
}
