#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <thread.h>
#include <addrspace.h>
#include <vm.h>
#include <machine/tlb.h>
#include <proc.h>
#include <current.h>
#include <spl.h>
#include <cpu.h>
#include <spinlock.h>
#include <mips/tlb.h>

/* Place your page table functions here */

/*
======================  HELPER FUNCTIONS  ======================
*/

// static paddr_t is_nocache(paddr_t pte)
// {
//     return (pte & TLBLO_NOCACHE);
// }

// static paddr_t is_dirty(paddr_t pte)
// {
//     return (pte & TLBLO_DIRTY);
// }

// static paddr_t is_valid(paddr_t pte)
// {
//     return (pte & TLBLO_VALID);
// }

/* extract the first 11 bits from the virtual address*/
static vaddr_t get_first_level(vaddr_t vaddr)
{
    return (vaddr >> 21); /* extract 21 to 31 bits */
}

/* extract the next 9 bits from the virtual address */
static vaddr_t get_second_level(vaddr_t vaddr)
{
    return (vaddr << 11) >> 23; /* extract 12 to 20 bits */
}

/* extract the 12 bit offset (bit 0 - 11) from the virtual address */
// static vaddr_t get_vaddr_offset(vaddr_t vaddr)
// {
//     return (vaddr & ~TLBHI_VPAGE);
// }

/* insert TLB entry */
static void tlb_insert(uint32_t entry_hi, uint32_t entry_lo)
{
    int spl = splhigh();
    tlb_random(entry_hi, entry_lo);
    splx(spl);
}

/*
===================== END OF HELPER FUNCTIONS ======================
*/

/* given a first level page table, if the value is null,
 * allocate some memory to a second level page table,
 * newly allocated pages are expected to be 0 filled.
 */
int pte_init(paddr_t **page_table, uint32_t first_level_index)
{
    page_table[first_level_index] = kmalloc(SECOND_LEVEL * sizeof(paddr_t));
    if (page_table[first_level_index] == NULL)
    {
        return ENOMEM;
    }
    memset(page_table[first_level_index], 0, SECOND_LEVEL * sizeof(paddr_t));
    return 0;
}

/* write to the page table entry with physical address and set bits*/
int insert_pte(paddr_t **page_table, vaddr_t first_level_index, vaddr_t second_level_index)
{
    /*give me one frame, tell me the virtual address, I can convert it to physical */
    vaddr_t page = alloc_kpages(1);
    if (page == 0) /* couldn't allocate a frame number */
    {
        return ENOMEM;
    }

    paddr_t p_page = KVADDR_TO_PADDR(page);

    /* zero fill the virtual address */
    // bzero((void *)page, PAGE_SIZE);
    bzero((void *)PADDR_TO_KVADDR(p_page), PAGE_SIZE);

    /* set the valid bit and dirty bit for TLB and Page replacement */
    page_table[first_level_index][second_level_index] = (p_page & PAGE_FRAME) | TLBLO_VALID | TLBLO_DIRTY;
    return 0;
}

void vm_bootstrap(void)
{
    /* Initialise any global components of your VM sub-system here.
     *
     * You may or may not need to add anything here depending what's
     * provided or required by the assignment spec.
     */
}

int vm_fault(int faulttype, vaddr_t faultaddress)
{
    int res;
    vaddr_t first_level_index, second_level_index;
    uint32_t entry_lo, entry_hi;
    struct addrspace *as = NULL;
    paddr_t **page_table = NULL;
    struct region *curr_region = NULL;
    int masked_perm;

    if (curproc == NULL)
    {
        /*
         * No process. This is probably a kernel fault early
         * in boot. Return EFAULT so as to panic instead of
         * getting into an infinite faulting loop.
         */
        return EFAULT;
    }

    /* handling readonly fault, if yes, return efault, if no, loop up page table */
    switch (faulttype)
    {
    case VM_FAULT_READONLY:
        return EFAULT;
    case VM_FAULT_READ:
        masked_perm = 0b100;
        break;
    case VM_FAULT_WRITE:
        masked_perm = 0b010;
        break;
    default:
        return EINVAL;
    }
    /* start looking up the page table */
    /* get the address space for the current process */
    as = proc_getas();
    if (as == NULL)
    {
        return EFAULT;
    }
    /* First level page table index */
    first_level_index = get_first_level(faultaddress);
    /* Second level page table index */
    second_level_index = get_second_level(faultaddress);

    /* get the page table */
    page_table = as->page_table;
    if (page_table == NULL)
    {
        return EFAULT;
    }

    /*
     * if top level page table entry is null, there is no valid translation
     * we need to initialise second level because we need to allocate later
     */
    if (page_table[first_level_index] == NULL)
    {
        res = pte_init(page_table, first_level_index);
        if (res)
        {
            return res;
        }
    }

    /*
     * if the second level page table entry has not been set, there is also no valid translation
     * check if the region is valid and has permissions before frame allocation and insert PTE
     */
    if (page_table[first_level_index][second_level_index] == 0)
    {
        /* there is no valid translation, start looking up region */
        curr_region = as->regions;

        /* loop through regions to check if the fault address is
         * a valid virtual address inside the regions
         *
         * NOTE: curr_region->size to be number of pages region spans (not in bytes)
         */
        while (curr_region != NULL)
        {
            if (faultaddress >= curr_region->start && faultaddress < curr_region->start + (curr_region->size * PAGE_SIZE))
            {
                if (curr_region->permissions & masked_perm)
                {
                    res = insert_pte(page_table, first_level_index, second_level_index);
                    if (res && page_table[first_level_index])
                    {
                        page_table[first_level_index] = NULL;
                        return res;
                    }
                    break;
                }
                else
                {
                    /* bad permissions */
                    return EFAULT;
                }
            }
            curr_region = curr_region->next_region;
            /* reaching the end of the linklist */
            if (curr_region == NULL)
            {
                page_table[first_level_index] = NULL;
                return EFAULT;
            }
        }
    }

    /* load the TLB entry to tlb */
    /* entry_lo: physical frame + dirty + valid bits */
    entry_lo = page_table[first_level_index][second_level_index];

    /* entry_hi: virtual page number + ASID (not implemented in asst3) */
    entry_hi = (faultaddress & TLBHI_VPAGE);

    tlb_insert(entry_hi, entry_lo);
    return 0;
}

/*
 * SMP-specific functions.  Unused in our UNSW configuration.
 */

void vm_tlbshootdown(const struct tlbshootdown *ts)
{
    (void)ts;
    panic("vm tried to do tlb shootdown?!\n");
}
