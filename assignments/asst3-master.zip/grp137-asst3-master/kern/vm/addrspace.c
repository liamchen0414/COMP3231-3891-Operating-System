/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <spl.h>
#include <spinlock.h>
#include <current.h>
#include <mips/tlb.h>
#include <addrspace.h>
#include <vm.h>
#include <proc.h>

/*
 * Note! If OPT_DUMBVM is set, as is the case until you start the VM
 * assignment, this file is not compiled or linked or in any way
 * used. The cheesy hack versions in dumbvm.c are used instead.
 *
 * UNSW: If you use ASST3 config as required, then this file forms
 * part of the VM subsystem.
 *
 */

/* initialise a 2 level page table */
static void pagetable_init(struct addrspace *as)
{
	as->page_table = (paddr_t **)alloc_kpages(2); /* allocate a page for top level page table */
	/* initialising the top level table to nulls at the start of the process*/
	for (int i = 0; i < TOP_LEVEL; i++)
	{
		as->page_table[i] = NULL;
	}
}

struct addrspace *
as_create(void)
{
	struct addrspace *as;

	as = kmalloc(sizeof(struct addrspace));
	if (as == NULL)
	{
		return NULL;
	}
	/* initialise the page table */
	pagetable_init(as);
	/* if page table initalisation fails, return null and free address space */
	if (as->page_table == NULL)
	{
		kfree(as);
		return NULL;
	}
	// set up a null pointer for regions linked list
	as->regions = NULL;

	return as;
}

int as_copy(struct addrspace *old, struct addrspace **ret)
{
	/* check if old is null */
	if (old == NULL)
	{
		return EFAULT;
	}

	struct addrspace *newas;

	newas = as_create();
	if (newas == NULL)
	{
		return ENOMEM;
	}

	/* we copy both the regions structure and also the page table */
	struct region *old_region_c = old->regions; /* old region counter */
	struct region *new_region_p = NULL;					/* new region previous pointer */
	struct region *new;													/* to hold new region instances */

	while (old_region_c)
	{

		/* 1. copy region */
		new = kmalloc(sizeof(struct region));
		if (new == NULL)
		{
			kfree(newas);
			return ENOMEM;
		}

		/* populate new region */
		new->start = old_region_c->start;
		new->size = old_region_c->size;
		new->is_stack = old_region_c->is_stack;
		new->permissions = old_region_c->permissions;
		new->old_permissions = old_region_c->old_permissions;
		new->next_region = NULL; /* need to point at the next region in newas */

		/* first node in new region list */
		if (new_region_p == NULL)
		{
			newas->regions = new;
		}
		else
		{
			new_region_p->next_region = new; /* now we have created the next one, point prev one to this */
		}

		new_region_p = new; /* keep track of this next one now for next iteration */
		old_region_c = old_region_c->next_region;
	}

	/* 2. copy page_table */
	paddr_t **old_pt = old->page_table;
	int i, j;
	int valid, dirty;
	/* traverse through old first level page table */
	for (i = 0; i < TOP_LEVEL; i++)
	{
		if (old_pt[i])
		{
			paddr_t *new_second_level = kmalloc(sizeof(paddr_t) * SECOND_LEVEL);
			if (new_second_level == NULL)
			{
				kfree(newas);
				return ENOMEM;
			}
			newas->page_table[i] = new_second_level;

			/* now traverse through old second level for non-empty entries to copy across */
			for (j = 0; j < SECOND_LEVEL; j++)
			{
				if (old_pt[i][j])
				{
					dirty = old_pt[i][j] & TLBLO_DIRTY;
					valid = old_pt[i][j] & TLBLO_VALID;

					/* allocate a new frame in physical memory to copy contents to,
					 * following dumbvm implementation
					 */
					vaddr_t new_frame_vaddr = alloc_kpages(1);
					memcpy((void *)new_frame_vaddr, (const void *)PADDR_TO_KVADDR(old_pt[i][j] & PAGE_FRAME), PAGE_SIZE);
					/* fill entry into new page_table */
					newas->page_table[i][j] = (KVADDR_TO_PADDR(new_frame_vaddr) & PAGE_FRAME) | dirty | valid;
				}
				else
				{ /* empty entry; set to 0 */
					old_pt[i][j] = 0;
				}
			}
		}
	}

	*ret = newas;
	return 0;
}

void as_destroy(struct addrspace *as)
{

	/*
	 * need to clean up contents of as:
	 * - regions
	 * - page table and its contents
	 */

	/* check address space not null */
	if (as == NULL)
	{
		return;
	}

	struct region *cur_region = as->regions;
	struct region *tmp_region;
	while (cur_region)
	{
		tmp_region = cur_region;
		cur_region = cur_region->next_region;
		kfree(tmp_region);
	}

	// if (tmp_region)
	// {
	// 	kfree(tmp_region);
	// 	tmp_region = NULL;
	// }

	/* free page table contents */
	for (int i = 0; i < TOP_LEVEL; i++)
	{
		if (as->page_table[i])
		{
			/* NOTE: remember to free_kpages (free actual frame) as well as kfree (the 2nd level table) */
			for (int j = 0; j < SECOND_LEVEL; j++)
			{
				if (as->page_table[i][j])
				{
					free_kpages(PADDR_TO_KVADDR(as->page_table[i][j] & PAGE_FRAME));
				}
			}
			kfree(as->page_table[i]);
			as->page_table[i] = NULL;
		}
	}
	kfree(as->page_table);
	as->page_table = NULL;

	kfree(as);
	as = NULL;
}

/* activate address space for new process? flush the tlb in here */
/* copied from dumbvm */
void as_activate(void)
{
	int i, spl;
	struct addrspace *as;

	as = proc_getas();
	if (as == NULL)
	{
		return;
	}

	/* Disable interrupts on this CPU while frobbing the TLB. */
	spl = splhigh();

	/* flushing TLB (this should be enough for basic assignment?) */
	for (i = 0; i < NUM_TLB; i++)
	{
		tlb_write(TLBHI_INVALID(i), TLBLO_INVALID(), i);
	}

	splx(spl);
}

void as_deactivate(void)
{
	/* Same as dumbvm; nothing here */
}

/*
 * Set up a segment at virtual address VADDR of size MEMSIZE. The
 * segment in memory extends from VADDR up to (but not including)
 * VADDR+MEMSIZE.
 *
 * The READABLE, WRITEABLE, and EXECUTABLE flags are set if read,
 * write, or execute permission should be set on the segment. At the
 * moment, these are ignored. When you write the VM system, you may
 * want to implement them.
 *
 * NOTE: we can also assume regions will not overlap for ASST3
 */
int as_define_region(struct addrspace *as, vaddr_t vaddr, size_t memsize,
										 int readable, int writeable, int executable)
{
	// create permissions flag
	int permissions = readable | writeable | executable;
	size_t size;

	// sanity check; load_elf should have gotten address space pointer
	// from proc_getas()
	KASSERT(as);

	// align the virtual address; can we align like dumbvm?
	// align region first
	memsize += vaddr & ~(vaddr_t)PAGE_FRAME;
	vaddr &= PAGE_FRAME;

	// align memsize
	memsize = (memsize + PAGE_SIZE - 1) & PAGE_FRAME;

	// number of pages
	size = memsize / PAGE_SIZE;

	// check for region within kuseg bounds and below stack region
	if (vaddr + memsize > (vaddr_t)(MIPS_KUSEG - STACK_N_PAGES * PAGE_SIZE))
	{
		return EFAULT;
	}

	int result = add_region(as, vaddr, size, permissions, 0);
	if (result)
	{
		return result;
	}

	return 0;
}

/*
 * Helper function to add a region to the end of the regions linked list
 * which tracks regions in a program's address space
 *
 * Function returns 0 on success, otherwise error code
 *
 */
int add_region(struct addrspace *as, vaddr_t vaddr, size_t size, uint32_t permissions, int is_stack)
{
	// create new region and set it
	struct region *new_region, *cur_region, *prev_region;
	new_region = kmalloc(sizeof(struct region));
	if (!new_region)
	{
		return EFAULT;
	}

	new_region->start = vaddr;
	new_region->size = size;
	new_region->is_stack = is_stack; // fix this; how to know if this is stack?
	new_region->permissions = permissions;
	new_region->old_permissions = permissions;
	new_region->next_region = NULL;

	// insert into linked list of regions; OREDERED BY start address
	// NOTE: we do not need to account for overlapping regions
	if (!as->regions)
	{
		as->regions = new_region;
	}
	else
	{
		cur_region = prev_region = as->regions; // initialise the loop
		while (cur_region && cur_region->start < new_region->start)
		{
			prev_region = cur_region;							// keep track of this
			cur_region = cur_region->next_region; // move onto the next
		}

		// the loop terminates where the new region should be inserted
		// between prev_region and cur_region
		prev_region->next_region = new_region;
		new_region->next_region = cur_region; // this may be null if we are at the end
	}

	return 0;
}

int as_prepare_load(struct addrspace *as)
{
	struct region *cur_region = as->regions;

	while (cur_region)
	{
		cur_region->old_permissions = cur_region->permissions;
		cur_region->permissions = 0x7;
		cur_region = cur_region->next_region;
	}

	return 0;
}

int as_complete_load(struct addrspace *as)
{
	struct region *cur_region = as->regions;

	while (cur_region)
	{
		cur_region->permissions = cur_region->old_permissions;
		cur_region = cur_region->next_region;
	}

	return 0;
}

int as_define_stack(struct addrspace *as, vaddr_t *stackptr)
{
	int result = add_region(as, USERSTACK - STACK_N_PAGES * PAGE_SIZE, STACK_N_PAGES, 0x7, 1);

	if (result)
	{
		return result;
	}

	/* Initial user-level stack pointer */
	*stackptr = USERSTACK;

	return result;
}
